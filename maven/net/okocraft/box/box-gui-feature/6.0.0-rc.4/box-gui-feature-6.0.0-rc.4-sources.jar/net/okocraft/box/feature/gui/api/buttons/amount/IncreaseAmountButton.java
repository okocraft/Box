package net.okocraft.box.feature.gui.api.buttons.amount;

import dev.siroshun.mcmsgdef.MessageKey;
import io.papermc.paper.registry.keys.SoundEventKeys;
import net.okocraft.box.feature.gui.api.button.ClickResult;
import net.okocraft.box.feature.gui.api.session.Amount;
import net.okocraft.box.feature.gui.api.session.PlayerSession;
import net.okocraft.box.feature.gui.api.session.TypedKey;
import net.okocraft.box.feature.gui.api.util.ItemEditor;
import net.okocraft.box.feature.gui.api.util.SoundBase;
import org.bukkit.Material;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public class IncreaseAmountButton extends AmountModificationButton {

    private static final SoundBase INCREASE_SOUND = SoundBase.builder().sound(SoundEventKeys.BLOCK_WOODEN_BUTTON_CLICK_ON).pitch(1.5f).build();

    private final MessageKey displayName;
    private final MessageKey.Arg1<Integer> clickToSetLore;
    private final MessageKey.Arg1<Integer> clickToIncreaseLore;
    private final MessageKey.Arg1<Integer> currentAmountLore;
    private final ClickResult returningResult;

    public IncreaseAmountButton(int slot, @NotNull TypedKey<Amount> dataKey,
                                @NotNull MessageKey displayName,
                                @NotNull MessageKey.Arg1<Integer> clickToSetLore,
                                @NotNull MessageKey.Arg1<Integer> clickToIncreaseLore,
                                @NotNull MessageKey.Arg1<Integer> currentAmountLore,
                                @NotNull ClickResult returningResult) {
        super(slot, dataKey);
        this.displayName = displayName;
        this.clickToSetLore = clickToSetLore;
        this.clickToIncreaseLore = clickToIncreaseLore;
        this.currentAmountLore = currentAmountLore;
        this.returningResult = returningResult;
    }

    @Override
    public @NotNull ItemStack createIcon(@NotNull PlayerSession session) {
        Amount amount = this.getOrCreateAmount(session);
        int unit = amount.getUnit().getAmount();
        int currentAmount = amount.getValue();

        return ItemEditor.create()
            .displayName(this.displayName)
            .loreEmptyLine()
            .loreLine(this.getClickToLore(unit, currentAmount).apply(unit))
            .loreEmptyLine()
            .loreLine(this.currentAmountLore.apply(currentAmount))
            .createItem(session.getViewer(), Material.BLUE_STAINED_GLASS_PANE);
    }

    private @NotNull MessageKey.Arg1<Integer> getClickToLore(int unit, int amount) {
        return unit != 1 && amount == 1 ? this.clickToSetLore : this.clickToIncreaseLore;
    }

    @Override
    public @NotNull ClickResult onClick(@NotNull PlayerSession session, @NotNull ClickType clickType) {
        Amount amount = this.getOrCreateAmount(session);
        Amount.Unit unit = amount.getUnit();
        int current = amount.getValue();

        if (current == 1 && unit.getAmount() != 1) {
            amount.setValue(unit.getAmount());
        } else {
            amount.increase();
        }

        INCREASE_SOUND.play(session.getViewer());

        return this.returningResult;
    }
}
