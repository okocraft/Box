package net.okocraft.box.storage.implementation.yaml;

import dev.siroshun.configapi.core.node.MapNode;
import dev.siroshun.configapi.format.yaml.YamlFormat;
import net.kyori.adventure.key.Key;
import net.okocraft.box.api.util.BoxLogger;
import net.okocraft.box.storage.api.model.data.CustomDataStorage;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.Stream;

public class YamlCustomDataStorage implements CustomDataStorage {

    private final Path customDataDirectory;

    public YamlCustomDataStorage(@NotNull Path rootDirectory) {
        this.customDataDirectory = rootDirectory.resolve("custom-data");
    }

    public void init() throws IOException {
        Files.createDirectories(this.customDataDirectory);
    }

    @Override
    public @NotNull MapNode loadData(@NotNull Key key) throws Exception {
        Path filepath = this.createFilepathFromKey(key);

        if (Files.isRegularFile(filepath)) {
            return YamlFormat.DEFAULT.load(filepath);
        } else {
            return MapNode.create();
        }
    }

    @Override
    public void saveData(@NotNull Key key, @NotNull MapNode mapNode) throws Exception {
        Path filepath = this.createFilepathFromKey(key);

        if (mapNode.value().isEmpty()) {
            Files.deleteIfExists(filepath);
        } else {
            Path parent = filepath.getParent();
            if (parent != null && Files.isDirectory(parent)) {
                Files.createDirectories(parent);
            }
            YamlFormat.DEFAULT.save(mapNode, filepath);
        }
    }

    @Override
    public void saveAllData(@NotNull Map<Key, MapNode> customDataMap) throws Exception {
        for (Map.Entry<Key, MapNode> entry : customDataMap.entrySet()) {
            this.saveData(entry.getKey(), entry.getValue());
        }
    }

    @Override
    public void visitData(@NotNull String namespace, @NotNull BiConsumer<Key, MapNode> consumer) throws Exception {
        if (!Key.parseableNamespace(namespace)) {
            throw new IllegalArgumentException("Invalid namespace: " + namespace);
        }

        try (Stream<@NotNull Path> listStream = Files.list(this.customDataDirectory)) {
            listStream.filter(Files::isDirectory)
                .filter(path -> path.getFileName().toString().equals(namespace))
                .forEach(dir -> {
                    try {
                        Files.walkFileTree(dir, new YamlFileVisitor(dir, consumer));
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                });
        } catch (UncheckedIOException e) {
            throw e.getCause();
        }
    }

    @Override
    public void visitAllData(@NotNull BiConsumer<Key, MapNode> consumer) throws Exception {
        try (Stream<@NotNull Path> listStream = Files.list(this.customDataDirectory)) {
            listStream.filter(Files::isDirectory)
                .forEach(dir -> {
                    try {
                        Files.walkFileTree(dir, new YamlFileVisitor(dir, consumer));
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                });
        } catch (UncheckedIOException e) {
            throw e.getCause();
        }
    }

    private @NotNull Path createFilepathFromKey(@NotNull Key key) {
        return this.customDataDirectory.resolve(key.namespace()).resolve(key.value() + ".yml");
    }

    private static class YamlFileVisitor implements FileVisitor<Path> {

        private final String namespace;
        private final BiConsumer<Key, MapNode> consumer;
        private final Path rootDir;

        private YamlFileVisitor(@NotNull Path rootDir, @NotNull BiConsumer<Key, MapNode> consumer) {
            this.rootDir = rootDir;
            this.namespace = rootDir.getFileName().toString();
            this.consumer = consumer;
        }

        @Override
        public @NotNull FileVisitResult preVisitDirectory(Path dir, @NotNull BasicFileAttributes attrs) {
            return FileVisitResult.CONTINUE;
        }

        @SuppressWarnings("PatternValidation")
        @Override
        public @NotNull FileVisitResult visitFile(Path file, @NotNull BasicFileAttributes attrs) throws IOException {
            String relative = this.rootDir.relativize(file).toString().replace(File.separatorChar, '/');

            if (!relative.endsWith(".yml")) {
                return FileVisitResult.CONTINUE;
            }

            String value = relative.substring(0, relative.length() - 4);

            if (Key.checkValue(value).isEmpty()) {
                this.consumer.accept(Key.key(this.namespace, value), YamlFormat.DEFAULT.load(file));
            } else {
                BoxLogger.logger().warn("Invalid value: {}", value);
            }

            return FileVisitResult.CONTINUE;
        }

        @Override
        public @NotNull FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
            throw exc;
        }

        @Override
        public @NotNull FileVisitResult postVisitDirectory(Path dir, IOException exc) {
            return FileVisitResult.CONTINUE;
        }
    }
}
