package net.okocraft.box.feature.category.internal.file;

import dev.siroshun.configapi.core.node.ListNode;
import dev.siroshun.configapi.core.node.MapNode;
import dev.siroshun.configapi.core.node.Node;
import dev.siroshun.configapi.core.node.StringRepresentable;
import dev.siroshun.configapi.format.yaml.YamlFormat;
import net.okocraft.box.api.BoxAPI;
import net.okocraft.box.api.model.item.BoxItem;
import net.okocraft.box.api.model.manager.ItemManager;
import net.okocraft.box.api.util.BoxLogger;
import net.okocraft.box.api.util.MCDataVersion;
import net.okocraft.box.feature.category.api.registry.CategoryRegistry;
import net.okocraft.box.feature.category.internal.category.CustomItemCategory;
import net.okocraft.box.feature.category.internal.category.LoadedCategory;
import net.okocraft.box.feature.category.internal.category.defaults.DefaultCategories;
import net.okocraft.box.feature.category.internal.category.defaults.DefaultCategory;
import org.bukkit.Material;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.UnaryOperator;

public final class CategoryFile implements AutoCloseable {

    public static final String DATA_VERSION_KEY = "$data-version";
    public static final String ITEMS_KEY = "items";
    public static final String ICON_KEY = "icon";
    public static final String DISPLAY_NAME_KEY = "display-name";
    public static final String LOCALE_DEFAULT = "default";
    public static final String DISABLED_CATEGORY = "disabled";

    private final Path filepath;
    private final CategoryRegistry registry;
    private final ItemManager itemManager;

    private MapNode loadedSource;
    private MCDataVersion version;

    public CategoryFile(@NotNull Path filepath, @NotNull CategoryRegistry registry, @NotNull ItemManager itemManager) {
        this.filepath = filepath;
        this.registry = registry;
        this.itemManager = itemManager;
    }

    @Override
    public void close() {
        this.loadedSource = null;
    }

    public CategoryFile loadFile() throws IOException {
        if (Files.isRegularFile(this.filepath)) {
            this.loadedSource = YamlFormat.COMMENT_PROCESSING.load(this.filepath);
            this.version = MCDataVersion.of(this.loadedSource.getInteger(DATA_VERSION_KEY));
        }
        return this;
    }

    public CategoryFile convertIfUnknownVersion() throws IOException {
        if (this.version == null || this.version.dataVersion() != 0) {
            return this;
        }

        Files.copy(this.filepath, this.filepath.getParent().resolve(this.filepath.getFileName().toString() + ".backup-" + System.currentTimeMillis()));

        MapNode mapNode = MapNode.create();
        UnaryOperator<String> patcher = BoxAPI.api().getItemManager().getItemNameConverter(MCDataVersion.MC_1_17);

        for (Object key : this.loadedSource.value().keySet()) {
            if (key.equals("icons")) {
                continue;
            } else if (key.equals("custom-items")) {
                ListNode newList = mapNode.createList(CustomItemCategory.CONFIG_KEY);
                this.loadedSource.getList(key).value().forEach(newList::add);
                continue;
            }

            MapNode map = mapNode.createMap(renameKey(key));
            map.set(ICON_KEY, this.loadedSource.getMap("icons").getString(key));
            addDefaultDisplayName(String.valueOf(key), map);

            ListNode items = map.createList(ITEMS_KEY);
            this.loadedSource.getList(key).asList(String.class).stream().map(patcher).forEach(items::add);
        }

        this.loadedSource = mapNode;
        return this;
    }

    public CategoryFile readCategoriesIfExists() {
        if (this.loadedSource == null) return this;

        for (Map.Entry<Object, Node<?>> entry : this.loadedSource.value().entrySet()) {
            String key = String.valueOf(entry.getKey());
            if (!key.startsWith("$") && entry.getValue() instanceof MapNode section) {
                this.loadAndRegisterCategory(key, section, BoxAPI.api().getItemManager().getItemNameConverter(this.version));
            }
        }

        return this;
    }

    public CategoryFile readCustomItemsIfExists() {
        if (this.loadedSource != null) {
            this.registry.getCustomItemCategory().addItems(this.toBoxItems(this.loadedSource.getList(CustomItemCategory.CONFIG_KEY).asList(String.class)));
        }
        return this;
    }

    public void addNewDefaultItemsIfNeeded() throws IOException {
        MapNode mapNode;
        List<DefaultCategory> defaultCategories;

        MCDataVersion currentVersion = MCDataVersion.current();

        if (this.version == null) {
            mapNode = MapNode.create();
            defaultCategories = DefaultCategories.loadDefaultCategories(currentVersion);
        } else if (currentVersion.isAfter(this.version)) {
            mapNode = Objects.requireNonNull(this.loadedSource);
            defaultCategories = DefaultCategories.loadNewItems(this.version, currentVersion);
        } else {
            return;
        }

        for (DefaultCategory category : defaultCategories) {
            List<String> items = category.itemNames();

            if (items.isEmpty()) {
                continue;
            }

            this.registry.getByName(category.key()).ifPresentOrElse(
                target -> {
                    target.addItems(this.toBoxItems(items));
                    ListNode list = mapNode.getOrCreateMap(category.key()).getOrCreateList(ITEMS_KEY);
                    items.forEach(list::add);
                },
                () -> {
                    this.registry.register(category.key(), category.toCategory(this.itemManager));
                    category.storeToMapNode(mapNode.createMap(category.key()));
                }
            );
        }

        mapNode.set(DATA_VERSION_KEY, currentVersion.dataVersion());
        YamlFormat.COMMENT_PROCESSING.save(mapNode, this.filepath);
    }

    private void loadAndRegisterCategory(@NotNull String key, @NotNull MapNode source, @NotNull UnaryOperator<String> itemNameConverter) {
        if (source.getBoolean(DISABLED_CATEGORY)) {
            return;
        }

        Material iconMaterial;

        try {
            iconMaterial = Material.valueOf(itemNameConverter.apply(source.getString(ICON_KEY)));
        } catch (IllegalArgumentException e) {
            BoxLogger.logger().warn("Unknown icon in '{}': {}", key, source.getString(ICON_KEY));
            iconMaterial = Material.STONE;
        }

        Map<Locale, String> displayNameMap;

        if (source.get(DISPLAY_NAME_KEY) instanceof MapNode mapNode) {
            Map<Locale, String> map = new HashMap<>();

            for (Map.Entry<Object, Node<?>> entry : mapNode.value().entrySet()) {
                if (entry.getKey() instanceof String locale && entry.getValue() instanceof StringRepresentable stringRepresentable) {
                    if (locale.equalsIgnoreCase(LOCALE_DEFAULT)) {
                        map.put(null, stringRepresentable.asString());
                    } else {
                        map.put(Locale.of(locale), stringRepresentable.asString());
                    }
                }
            }

            displayNameMap = map;
        } else {
            displayNameMap = Collections.emptyMap();
        }

        List<String> itemNameList = source.getList(ITEMS_KEY).asList(String.class);
        List<BoxItem> items = new ArrayList<>(itemNameList.size());

        for (String name : itemNameList) {
            BoxAPI.api().getItemManager().getBoxItem(itemNameConverter.apply(name)).ifPresent(items::add);
        }

        LoadedCategory category = new LoadedCategory(iconMaterial, displayNameMap);
        category.addItems(items);
        this.registry.register(key, category);
    }

    private @NotNull Collection<BoxItem> toBoxItems(@NotNull List<String> itemNames) {
        return itemNames.stream().map(this.itemManager::getBoxItem).filter(Optional::isPresent).map(Optional::get).toList();
    }

    private static Object renameKey(@NotNull Object key) {
        return switch (String.valueOf(key)) {
            case "woods" -> "woods-1";
            case "horse" -> "mob-equipment";
            default -> key;
        };
    }

    private static void addDefaultDisplayName(@NotNull String key, @NotNull MapNode target) {
        Map<String, String> displayNameMap = switch (key) {
            case "armors" -> Map.of(LOCALE_DEFAULT, "Armors", "ja", "防具");
            case "bows" -> Map.of(LOCALE_DEFAULT, "Bows", "ja", "弓矢");
            case "candles" -> Map.of(LOCALE_DEFAULT, "Candles", "ja", "ろうそく");
            case "concretes" -> Map.of(LOCALE_DEFAULT, "Concretes", "ja", "コンクリート");
            case "custom-items" -> Map.of(LOCALE_DEFAULT, "Custom Items", "ja", "カスタムアイテム");
            case "decorated-pot" -> Map.of(LOCALE_DEFAULT, "Decorated Pots", "ja", "飾り壺");
            case "decorations" -> Map.of(LOCALE_DEFAULT, "Decorations", "ja", "装飾アイテム");
            case "dirt" -> Map.of(LOCALE_DEFAULT, "Dirt", "ja", "土類");
            case "dyes" -> Map.of(LOCALE_DEFAULT, "Dyes", "ja", "染料");
            case "enchanted-books" -> Map.of(LOCALE_DEFAULT, "Enchanted Books", "ja", "エンチャント本");
            case "end" -> Map.of(LOCALE_DEFAULT, "End", "ja", "エンド");
            case "experimental" -> Map.of(LOCALE_DEFAULT, "Experimental Items", "ja", "実験的アイテム");
            case "farms" -> Map.of(LOCALE_DEFAULT, "Farms", "ja", "農業・食料");
            case "flowers" -> Map.of(LOCALE_DEFAULT, "Flowers", "ja", "草花");
            case "glasses" -> Map.of(LOCALE_DEFAULT, "Glasses", "ja", "ガラス");
            case "horse" -> Map.of(LOCALE_DEFAULT, "Mob Equipment", "ja", "モブ用装備");
            case "misc" -> Map.of(LOCALE_DEFAULT, "Misc", "ja", "その他");
            case "mob-drops" -> Map.of(LOCALE_DEFAULT, "Mob Drops", "ja", "モブドロップ品");
            case "mushrooms" -> Map.of(LOCALE_DEFAULT, "Mushrooms", "ja", "きのこ");
            case "music-discs" -> Map.of(LOCALE_DEFAULT, "Music Discs", "ja", "ディスク");
            case "nether" -> Map.of(LOCALE_DEFAULT, "Nether", "ja", "ネザー");
            case "oceans" -> Map.of(LOCALE_DEFAULT, "Oceans", "ja", "海類");
            case "ores" -> Map.of(LOCALE_DEFAULT, "Ores", "ja", "鉱石");
            case "potions" -> Map.of(LOCALE_DEFAULT, "Potions", "ja", "ポーション");
            case "rails" -> Map.of(LOCALE_DEFAULT, "Rails", "ja", "レール");
            case "redstones" -> Map.of(LOCALE_DEFAULT, "Redstones", "ja", "レッドストーン");
            case "sand" -> Map.of(LOCALE_DEFAULT, "Sand", "ja", "砂類");
            case "sculk" -> Map.of(LOCALE_DEFAULT, "Sculk", "ja", "スカルク");
            case "shulker-boxes" -> Map.of(LOCALE_DEFAULT, "Shulker Boxes", "ja", "シュルカーボックス");
            case "spawn-eggs" -> Map.of(LOCALE_DEFAULT, "Spawn Eggs", "ja", "スポーンエッグ");
            case "stones" -> Map.of(LOCALE_DEFAULT, "Stones", "ja", "石類");
            case "terracotta" -> Map.of(LOCALE_DEFAULT, "Terracotta", "ja", "テラコッタ");
            case "tools" -> Map.of(LOCALE_DEFAULT, "Tools", "ja", "ツール");
            case "unavailable" -> Map.of(LOCALE_DEFAULT, "Unavailable", "ja", "入手不可");
            case "uncategorized" -> Map.of(LOCALE_DEFAULT, "Uncategorized", "ja", "未分類");
            case "woods" -> Map.of(LOCALE_DEFAULT, "Woods", "ja", "木材");
            case "woods-2" -> Map.of(LOCALE_DEFAULT, "Woods", "ja", "木材");
            case "wools" -> Map.of(LOCALE_DEFAULT, "Wools", "ja", "羊毛");
            default -> null;
        };

        if (displayNameMap != null) {
            target.set(DISPLAY_NAME_KEY, displayNameMap);
        }
    }
}
