package net.okocraft.box.feature.autostore.listener;

import com.github.siroshun09.event4j.listener.ListenerBase;
import com.github.siroshun09.event4j.priority.Priority;
import net.kyori.adventure.key.Key;
import net.okocraft.box.api.BoxProvider;
import net.okocraft.box.api.event.player.PlayerLoadEvent;
import net.okocraft.box.api.event.player.PlayerUnloadEvent;
import net.okocraft.box.api.util.BoxLogger;
import net.okocraft.box.feature.autostore.message.AutoStoreMessage;
import net.okocraft.box.feature.autostore.model.AutoStoreSettingContainer;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class BoxPlayerListener {

    public void register(@NotNull Key listenerKey) {
        BoxProvider.get().getEventManager().subscribeAll(List.of(
                new ListenerBase<>(PlayerLoadEvent.class, listenerKey, this::onLoad, Priority.NORMAL),
                new ListenerBase<>(PlayerUnloadEvent.class, listenerKey, this::onUnload, Priority.NORMAL)
        ));
    }

    public void unregister(@NotNull Key listenerKey) {
        BoxProvider.get().getEventManager().unsubscribeByKey(listenerKey);
    }

    private void onLoad(@NotNull PlayerLoadEvent event) {
        var player = event.getBoxPlayer().getPlayer();

        try {
            AutoStoreSettingContainer.INSTANCE.load(player);
        } catch (Exception e) {
            BoxLogger.logger().error("Could not load autostore setting ({})", player.getName(), e);
            player.sendMessage(AutoStoreMessage.ERROR_FAILED_TO_LOAD_SETTINGS);
        }
    }

    private void onUnload(@NotNull PlayerUnloadEvent event) {
        var player = event.getBoxPlayer().getPlayer();

        try {
            AutoStoreSettingContainer.INSTANCE.unload(player);
        } catch (Exception e) {
            BoxLogger.logger().error("Could not unload autostore setting ({})", player.getName(), e);
        }
    }
}
